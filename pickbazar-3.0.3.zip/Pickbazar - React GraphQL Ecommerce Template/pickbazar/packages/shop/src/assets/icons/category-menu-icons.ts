export { FruitsVegetable } from 'assets/icons/FruitsVegetable';
export { FacialCare } from 'assets/icons/FacialCare';
export { Handbag } from 'assets/icons/Handbag';
export { DressIcon } from 'assets/icons/DressIcon';
export { FurnitureIcon } from 'assets/icons/FurnitureIcon';
export { BookIcon } from 'assets/icons/BookIcon';
export { MedicineIcon } from 'assets/icons/MedicineIcon';
export { Restaurant } from 'assets/icons/Restaurant';
