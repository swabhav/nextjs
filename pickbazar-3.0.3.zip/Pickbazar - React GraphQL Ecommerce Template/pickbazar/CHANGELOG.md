version: 3.0.3

1. introduce site-settings folder for easy site configurations.
2. change theme configurations for better customizations.
3. improve some component's structure.
4. improve some design facts.
5. improve internationalization naming.
6. replace google fonts CDN by typeface.
7. add placeholder for empty cart.
8. fix api data.
