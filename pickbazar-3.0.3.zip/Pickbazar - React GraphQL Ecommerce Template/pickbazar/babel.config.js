module.exports = {
  babelrcRoots: ['.', 'packages/*'],
};
